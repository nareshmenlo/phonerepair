<style type="text/css">
    .brief_desc{
        font-size: 18px;
    }
</style>
<section  id="ccr-left-section" class="col-md-8"> 
    <div class="container"  >
        <div class="col-md-6 sortable-item_style_2 bigstory">
                <section class="padding0"  id="ccr-slide-main" class="carousel slide" data-ride="carousel">
                    <!-- Carousel items -->
                    <div class="carousel-inner">
                        <?php
                        $banners=getHeaderBanners();
                        $i = 1;
                        if(isset($banners)){
                        foreach ($banners as $banner): if ($i == 1) {
                                ?>
                                <div class="active item">
                                <?php } else { ?>
                                    <div class="item">
                                    <?php } $i++; ?>
                                   
                                    <div class="container slide-element">
                                        <a  href="<?php echo base_url('banner/single/' . $banner->id.'/'.url_title($banner->title)); ?>">
                                        <img src="<?php echo base_url(); ?>useruploadfiles/postimages/<?php echo $banner->image; ?>"
                                             class="img-responsive">
                                        <p><a  href="<?php echo base_url('banner/single/' . $banner->id.'/'.url_title($banner->title)); ?>"><?php echo $banner->title; ?></a></p>
                                        </a>
                                    </div> <!-- /.slide-element -->
                                </div> <!--/.active /.item -->

                                <!-- /.item -->
                            <?php endforeach; } ?>

                        </div> <!-- /.carousel-inner -->

                        <!-- /.carousel-indicators -->

                        <!-- slider nav -->
                        <a class="carousel-control left" href="#ccr-slide-main" data-slide="prev"><i class="fa fa-arrow-left"></i></a>
                        <a class="carousel-control right" href="#ccr-slide-main" data-slide="next"><i class="fa fa-arrow-right"></i></a>
                    </section>
        </div>
        <div class="col-md-6 sortable-item_style_2">
            <section id="sidebar-popular-post">
                <div class="headingBtm" >
                    <span></span> 
                    <p class="title_color"><strong>TOP STORIES</strong></p>
                </div> <!-- .ccr-gallery-ttile -->
                <ul class="mostpopular_news news_style">
                    <?php if (count($topstories) > 0) { ?> 
                        <?php foreach ($topstories as $story): ?>
                            <li>
                                <a  href="<?php echo base_url() . getController($story->pagename) . '/single/' . $story->id; ?>"><?php echo $story->title; ?></a>
                            </li>
                        <?php endforeach; ?>
                    <?php }else { ?>
                        <li><a>Most Papular News are not available</a></li>
                    <?php } ?>  
                </ul>     
            </section>
        </div>
    </div>

    <div class="col-md-12 sortable-item_style_2 video_widg">
        <section id="sidebar-popular-post" class="highlights">
            <div class="headingBtm" >
                <span></span> 
                <p class="title_color"><strong>WATCH</strong></p>
            </div> <!-- .ccr-gallery-ttile -->

            <ul class="video_list_spr list-inline ">
                <?php 
                $videos = latestVideos();
                if(count($videos)>0){
                    foreach($videos as $video){ ?>
                <li>
                    <a title="" rel="bookmark" href="<?php echo base_url(); ?>videos/index/<?php echo $video->id; ?>" class="thumb">
                        <div class="ytp-thumbnail-overlay1 ytp-cued-thumbnail-overlay" data-layer="4" style="background-image: url('https://i.ytimg.com/vi/<?php echo $video->vedio; ?>/hqdefault.jpg');">
                            <img class="youtubeplaybtn1"  src="<?php echo  asset_url().'/img/youtubeplayas.png'; ?>">
                        </div>
                        </a>
                    <a href="<?php echo base_url(); ?>videos/index/<?php echo $video->id; ?>" class="caption"><?php echo $video->vedio_name; ?></a>
                </li>
                <?php } } ?>
            </ul>
        </section>
    </div>
    <div class="container"  >
        <div class="col-md-6 sortable-item_style_2 bigstory padding0">
            <section id="sidebar-popular-post">
                <div class="headingBtm topics" >
                    <span></span> 
                    <p class="title_color"><a  href="<?php echo base_url(); ?>movienews"> <strong>MOVIE NEWS</strong><span class="more_arrow"></span></a></p>
                </div> <!-- .ccr-gallery-ttile -->

                <ul class="mostpopular_news news_style">
                    <?php if (count($movienews) > 0) { ?> 
                        <?php foreach ($movienews as $movienew): ?>
                            <li>
                                <a  href="<?php echo base_url() . 'movienews/single/' . $movienew->id; ?>"><?php echo $movienew->title; ?></a>
                            </li>
                        <?php endforeach; ?>
                    <?php }else { ?>
                        <li><a>Stories are not available</a></li>
                    <?php } ?>  
                </ul> 
            </section>

        </div>
        <div class="col-md-6 sortable-item_style_2 bigstory padding0">
            <section id="sidebar-popular-post">
                <div class="headingBtm topics" >
                    <span></span> 
                    <p class="title_color"><a href="<?php echo base_url(); ?>political"> <strong>POLITICAL NEWS</strong><span class="more_arrow"></span></a></p>
                </div> <!-- .ccr-gallery-ttile -->
                <ul class="mostpopular_news news_style">
                    <?php if (count($politicalnews) > 0) { ?> 
                        <?php foreach ($politicalnews as $political): ?>
                            <li>
                                <a  href="<?php echo base_url() . 'political/single/' . $political->id; ?>"><?php echo $political->title; ?></a>
                            </li>
                        <?php endforeach; ?>
                    <?php }else { ?>
                        <li><a>political are not available</a></li>
                    <?php } ?>  
                </ul> 
            </section>
        </div>
    </div>
    <div class="container"  >
        <div class="col-md-6 sortable-item_style_2 bigstory padding0">
            <section id="sidebar-popular-post">
                <div class="headingBtm topics" >
                    <span></span> 
                    <p class="title_color"><a href="<?php echo base_url(); ?>editorchoice"> <strong>Editorial Choice</strong><span class="more_arrow"></span></a></p>
                </div> <!-- .ccr-gallery-ttile -->

                <ul class="mostpopular_news news_style">
                    <?php if (count($editor_choices) > 0) { ?> 
                        <?php foreach ($editor_choices as $editor_choice): ?>
                            <li>
                                <a  href="<?php echo base_url() . 'editorchoice/single/' . $editor_choice->id; ?>"><?php echo $editor_choice->title; ?></a>
                            </li>
                        <?php endforeach; ?>
                    <?php }else { ?>
                        <li><a>editor_choices are not available</a></li>
                    <?php } ?>  
                </ul> 
            </section>
        </div>
        <div class="col-md-6 sortable-item_style_2 bigstory padding0">
            <section id="sidebar-popular-post">
                <div class="headingBtm topics" >
                    <span></span> 
                    <p class="title_color"><a href="<?php echo base_url(); ?>moviereviews"> <strong>REVIEWS</strong><span class="more_arrow"></span></a></p>
                </div> <!-- .ccr-gallery-ttile -->
                <ul class="mostpopular_news news_style">
                    <?php if (count($reviews) > 0) { ?> 
                        <?php foreach ($reviews as $review): ?>
                            <li>
                                <a  href="<?php echo base_url() . 'moviereviews/single/' . $review->id; ?>"><?php echo $review->title; ?></a>
                            </li>
                        <?php endforeach; ?>
                    <?php }else { ?>
                        <li><a>Reviews are not available</a></li>
                    <?php } ?>  
                </ul> 
            </section>
        </div>
    </div>
</section>

