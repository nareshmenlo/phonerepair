
<section id="ccr-left-section" class="col-md-8">

    <div class="current-page">
        <div class="header"> Movie News </div>
    </div> <!-- / .current-page -->

    <section id="ccr-category-1">
        <ul class="mostpopular_news liview">
            <?php
            $leftdesc = 0;
            if (count($movienews) > 0) {
                foreach ($movienews as $t):
                    ?>
                    <li>
                        <div class="brief_box row">
                            <!-- <div class="colo-md-3 padding0"><?php
                                if ($t->image != '') {
                                    ?><a href="<?php echo base_url('movienews/single/' . $t->id); ?>">
                                        <img style="float:left;" class="brief_img" src="<?php echo base_url(); ?>useruploadfiles/postimages/<?php echo $t->image; ?>" >
                                    </a>
                                    <?php } ?>
                                </div> -->

                                <?php if ($t->image != '') { ?>
                            <div class="colo-md-3 padding0">
                                <a href="<?php echo base_url('movienews/single/' . $t->id); ?>">
                                    <img style="float:left;" class="brief_img" src="<?php echo base_url(); ?>useruploadfiles/postimages/<?php echo $t->image; ?>" >
                                </a>
                            </div>
                            <div class="col-md-9 padding0">
                            <?php } else { ?>
                            <div class="col-md-12 padding0">
                            <?php } ?>
                                <div class="brief_title">
	                                <a style="font-weight:bold;" href="<?php echo base_url('movienews/single/' . $t->id); ?>"><?php echo $t->title; ?></a>
	                             </div>
	                            <div class="brief_desc">
        							<?php echo trim(strip_tags($t->description)); ?>
                                </div>
                            </div>

                        </div>
                    </li>
                <?php endforeach;
            } else {
                ?>
                <li>movienews are not available</li>
<?php } ?> 
        </ul>
        <nav class="nav-paging">
            <ul> <?php echo $pagination_helper->create_links(); ?> 

            </ul>
        </nav>
    </section>

</section>