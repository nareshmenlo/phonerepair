
<section id="ccr-left-section" class="col-md-8">

    <div class="current-page">
        <a href="<?php echo base_url(); ?>"><i class="fa fa-home"></i> <i class="fa fa-angle-double-right"></i></a> 
        <a href="<?php echo base_url(); ?>gossipis">Gossips<i class="fa fa-angle-double-right"></i></a> 
        Political Gossips <i class="fa fa-angle-double-right"></i>
    </div> <!-- / .current-page -->
    <?php
    if (isset($id)) {
        $gossipisById = isset($gossipisById[0]) ? $gossipisById[0] : header("Location: " . base_url('gossipis/'));
        ?>
        <article id="ccr-article"  class="clearfix">
            <h1><a href="<?php echo base_url('gossipis/single/' . $gossipisById->id); ?>" ><?php echo $gossipisById->title; ?></a></h1>
    <?php if ($gossipisById->image != "") { ?>
                <div class="clearfix" align="center">
                    <img src="<?php echo base_url(); ?>useruploadfiles/postimages/<?php echo $gossipisById->image; ?>" alt="1st Image">
                </div><?php } ?>	
            <br/>
    <?php echo $gossipisById->description; ?>
    </article> <!-- /#ccr-single-post -->
<?php } ?>

    <section id="ccr-article-related-post">
<?php if (isset($id)) { ?>	<div class="ccr-gallery-ttile">
                <span class="bottom"></span>
                <p class="title_color">Related Posts</p>
            </div> <!-- .ccr-gallery-ttile --><?php } ?>
        <ul class="mostpopular_news">
            <?php
            $leftdesc = 0;
            if (count($gossipis) > 0) {
                foreach ($gossipis as $t):
                    if (isset($id) && $id == $t->id) {
                        continue;
                    }
                    ?>
                    <li>
                        <div class="brief_box">
                            <div class="brief_title">
                                <a class="pull-left" style="font-weight:bold;" href="<?php echo base_url('gossipis/single/' . $t->id); ?>"><?php echo $t->title; ?></a>
                            </div>
                            <div style="" class="pull-left">
                                <?php
                                if ($t->image != '') {
                                    ?><a href="<?php echo base_url('gossipis/single/' . $t->id); ?>">
                                        <img style="float:left;" class="brief_img" src="<?php echo base_url(); ?>useruploadfiles/postimages/<?php echo "370_250_" . $t->image; ?>" >
                                    </a>
        <?php } ?>
                                <div class="brief_desc">
                    <?php echo trim(strip_tags($t->description)); ?>
                                </div>
                            </div>

                        </div>
                    </li>
    <?php endforeach;
} else { ?>
                <li><a>Gossipis are not available</a></li>
<?php } ?> 
        </ul>

    </section>

    <section class="bottom-border"></section> <!-- /#bottom-border -->

</section>


