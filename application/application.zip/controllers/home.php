<?php  if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class  Home extends CI_Controller {

    public function index()
    {
        $this->load->model('home_model');
        $data=$side=[];
        $data['politicalnews'] = $this->home_model->getAll('political');
        $data['popular'] = $this->home_model->getAll('popular');
        $data['movienews'] = $this->home_model->getAll('cinema');
        $data['reviews'] = $this->home_model->getAll('movie_reviews');
        $data['gossips'] = $this->home_model->getAll('gossips');
        $title['title'] = "Topfilmnews Portal";
        $this->load->view('header',$title);
        $this->load->view('home',$data);
        //$this->load->view('sidebar',$side);
        $this->load->view('footer');
    }

    public function contactus(){
        $title['title'] = "Top Film News Portal | Contact Us";
        $this->load->view('header',$title);
        $this->load->view('contactus');
        $this->load->view('sidebar');
        $this->load->view('footer');    
    }
}
