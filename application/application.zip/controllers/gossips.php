<?php   if ( ! defined('BASEPATH')) exit('No direct script access allowed');



class gossips extends CI_Controller {

	function __construct()

	{

		parent::__construct();

	}
	public function index($page=1)

	{

		$this->load->model('home_model');

		$this->load->library('pagination');

		$this->load->library('paginationlib');

		try

		{

			$pagingConfig   = $this->paginationlib->initPagination("gossips/index",$this->home_model->get_count_pagename('gossips'),11,3);

 			$data["pagination_helper"]   = $this->pagination;

			$data["gossips"] = $this->home_model->get_by_pagename_range('gossips',(($page-1) * $pagingConfig['per_page']),$pagingConfig['per_page']);

			$title['title'] = "gossips";

 			

  			$this->load->view('header',$title);

			$this->load->view('gossips',$data);

			$this->load->view('sidebar',$data);

			$this->load->view('footer');

		}

		catch (Exception $err)

		{

			log_message("error", $err->getMessage());

			return show_error($err->getMessage());

		}

		

	}

	public function single($id)

	{

		$this->load->model('home_model');

		$data['id']=$id;

		$data['gossips'] = $this->home_model->getAll("gossips");

		

		$data['gossipsById'] = $this->home_model->getPostById($id,"gossips");

 		$title['articleimage'] = $data['gossipsById'][0]->image;//"Movie News";
 		$title['title'] = $data['gossipsById'][0]->title;//"Movie News";
		$title['description'] = substr(strip_tags($data['gossipsById'][0]->description),0,800);

		$this->load->view('header',$title);

		$this->load->view('gossipssingle',$data);

		$this->load->view('sidebar',$data);

		$this->load->view('footer');

	}

}

