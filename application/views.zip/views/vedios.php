<?php //print_r($single);exit; ?>
<section id="ccr-left-section" class="col-md-8">

 <article>
     <h2 class="singlevideo_title"><?php echo $single->vedio_name; ?></h2>
     <div class="text-right">
    <?php $this->load->view('social_media');?>
</div>
        <ul class="ccr-category-post vediosUl">
                <li>
                    <div class="ccr-thumbnail">
 <iframe id="I1" allowfullscreen="" frameborder="0" height="400" width="100%" name="I1" src="http://www.youtube.com/embed/<?php echo $single->vedio; ?>?autoplay=1"></iframe>                    </div>
                   
                </li>
        </ul>
    </article> <!-- / #ccr-category -->
    <article class="row">
        <section>
            <div class="latest_video" >
                <h3 class="title h2">Latest vedios</h3>		 <!-- Article start -->
                <div class="col-md-12">
                    <?php foreach ($vedios as $video): ?>
                        <div class="col-md-4" style="height: 180px;">
                            <div class="view-img">
                                <a title="" rel="bookmark" href="<?php echo base_url(); ?>videos/index/<?php echo $video->id; ?> " class="video_thumb">
                                    <div class="ytp-thumbnail-overlay ytp-cued-thumbnail-overlay" data-layer="4" style="background-image: url('https://i.ytimg.com/vi/<?php echo $video->vedio; ?>/hqdefault.jpg');">
                                        <img class="youtubeplaybtn"  src="<?php echo  asset_url().'/img/youtubeplayas.png'; ?>">
                                    </div>
                                </a>
                            </div>
                            <div class="view-desc">
                                <h6><a href="<?php echo base_url(); ?>videos/index/<?php echo $video->id; ?>"><?php echo substr($video->vedio_name, 0, 50); ?></a></h6>
                                <span class="byline"> 
                                </span>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </section>
    </article>
    <!--    <nav class="nav-paging ">
            <ul> <?php //echo $pagination_helper->create_links();       ?>    </ul>
        </nav>-->

</section>