<div class="col-md-12 padding0" style="clear:both;">
<!-- <img src="<?php echo asset_url(); ?>img/add001.jpg" /> -->
</div>
	</div><!-- /.container -->
</section><!-- / #ccr-main-section -->

<footer id="ccr-footer">
	<div class="container">
	 	<div class="copyright">
	 		<?php copyrights(); ?>
	 	</div> <!-- /.copyright -->

	</div> <!-- /.container -->
    <a href="#" class="scrollToTop"><i class="fa fa-2x fa-arrow-circle-up"></i></a>
</footer>  <!-- /#ccr-footer -->
<script src="<?php echo asset_url(); ?>js/jquery.min.js"></script>
<script src="<?php echo asset_url(); ?>js/bootstrap.min.js"></script>
<!-- <script src="<?php echo asset_url(); ?>js/jquery.social-buttons.js">	</script> -->

<!-- <script src="<?php echo asset_url(); ?>js/jquery.newsTicker.js"></script> -->
<!-- <script src="<?php echo asset_url(); ?>js/custom.js"></script> -->
<!-- <script src="<?php echo asset_url(); ?>js/jquery.prettyPhoto.js"></script> -->
<!-- <script src="<?php echo asset_url(); ?>js/jquery.share.js"></script> -->
<script src="<?php echo asset_url(); ?>js/owl.carousel.js"></script>
<script type="text/javascript">
$(document).ready(function() {
	var owl = $('.owl-carousel');
	owl.owlCarousel({
	    items:5,
	    loop:true,
	    margin:10,
	    autoplay:true,
	    autoplayTimeout:1000,
	    autoplayHoverPause:true,
	     responsiveClass:true,
	    responsive:{
	        0:{
	            items:1,
	            nav:true
	        },
	        600:{
	            items:3,
	            nav:false
	        },
	        1000:{
	            items:5,
	            nav:true,
	            loop:false
	        }
	    }
	});
	$('.play').on('click',function(){
	    owl.trigger('play.owl.autoplay',[1000])
	})
	$('.stop').on('click',function(){
	    owl.trigger('stop.owl.autoplay')
	})
	$('.vedio-curosal').owlCarousel({
	    items:5,
	    loop:true,
	    margin:10,
	    autoplay:true,
	    autoplayTimeout:1000,
	    autoplayHoverPause:true,
	     responsiveClass:true,
	    responsive:{
	        0:{
	            items:1,
	            nav:true
	        },
	        600:{
	            items:3,
	            nav:false
	        },
	        1000:{
	            items:5,
	            nav:true,
	            loop:false
	        }
	    }
	});
	$(window).scroll(function(){
		if ($(this).scrollTop() > 100) {
			$('.scrollToTop').fadeIn();
		} else {
			$('.scrollToTop').fadeOut();
		}
	});
	$('.scrollToTop').click(function(){
		$('html, body').animate({scrollTop : 0},800);
		return false;
	});
	
	//$("[rel^='lightbox']").prettyPhoto();
	
	function checkImg(img) {
        if (img.naturalHeight <= 1 && img.naturalWidth <= 1) {
            // undersize image here
            img.src = "<?php echo asset_url(); ?>img/noimage.png";
        }
    }

    $("img").each(function() {
        // if image already loaded, we can check it's height now
        if (this.complete) {
            checkImg(this);
        } else {
            // if not loaded yet, then set load and error handlers
            $(this).load(function() {
                checkImg(this);
            }).error(function() {
                // img did not load correctly
                // set new .src here
                this.src = "<?php echo asset_url(); ?>img/noimage.png";
            });

        }
    });

});
</script>
<script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-93490450-1', 'auto');
  ga('send', 'pageview');

</script>

</body>
</html>