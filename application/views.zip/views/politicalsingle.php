    <section id="ccr-left-section" class="col-md-8">

            <div class="current-page">
                <a href="<?php echo base_url();?>"><i class="fa fa-home"></i> <i class="fa fa-angle-double-right"></i></a> 
                <a href="<?php echo base_url();?>political">&nbsp;&nbsp;Political&nbsp;&nbsp;<i class="fa fa-angle-double-right"></i></a> 
                Political News<div class="pull-right">
    <?php $this->load->view('social_media');?>
</div>
            </div> <!-- / .current-page -->
<?php 
 if(isset($id)){
                     $politicalbyId=isset($politicalById[0])?$politicalById[0]:header("Location: ".base_url('political/'));
                     
 ?>
            <article id="ccr-article"  class="clearfix">
                <h1><?php echo  $politicalbyId->title; ?></h1>
<div class="clearfix" align="center">
                <img src="<?php echo base_url(); ?>useruploadfiles/postimages/<?php echo $politicalbyId->image; ?>" alt="1st Image"></div><br/>
                <?php echo $politicalbyId->description; ?>


            </article> <!-- /#ccr-single-post -->
<?php } ?>

            <section id="ccr-article-related-post">
             <?php if(isset($id)){?>    <div class="ccr-gallery-ttile">
                        <span class="bottom"></span>
                        <p class="title_color">Related Posts</p>
                </div> <!-- .ccr-gallery-ttile --><?php } ?>
                <ul>
                    <?php 
                    //$k=0;
                    foreach($political as $news):
                    if(isset($id)&&$id==$news->id){
                        continue;
                    }
                    ?>
                    <li>
                        
                        <div class="ccr-thumbnail movieThumbs">
                            <img src="<?php echo base_url(); ?>useruploadfiles/postimages/<?php echo $news->image; ?>" >
                            <p><a href="<?php echo base_url('political/single/'.$news->id); ?>">Read More</a></p>
                        </div>
                        <span><a href="<?php echo base_url('political/single/'.$news->id); ?>"><?php echo $news->title; ?></a></span>
                    </li>
                    <?php 
                    endforeach;?>
                    </ul>

            </section>

            <section class="bottom-border"></section> <!-- /#bottom-border -->

        </section>


