<section id="ccr-left-section" class="col-md-8">
	<style type="text/css">
	.glleryTitile{
	    color: #000 !important;
	    margin-top: 10px;
	    text-transform: capitalize;
	    font-size: 17px;
	}
	.current-page{
		text-transform: capitalize;
		color: #000;
		font-weight: bold;
	}
	.current-page a{
		text-decoration: underline;
		color: #000;
	}
	#ccr-left-section > div > div > a > img{
		padding:8px;
	}
	.framedecoration{
	    overflow: hidden;
	    border: 5px solid #ddd;
	    margin: 8px 8px;
	    box-shadow: 2px 2px 2px #bbb;
	    display: inline-block;
	    width: 200px;
	}
	.overme {
	    width: 185px;
	    overflow:hidden; 
	    white-space:nowrap; 
	    text-overflow: ellipsis;
	    color: red;
	}
	</style>
	<div class="current-page">
		<a href="<?php echo base_url(); ?>">Home</a>&nbsp;&nbsp;<i class="fa fa-angle-double-right"></i>&nbsp;&nbsp;Gallery
	</div> <!-- / .current-page -->
	<?php 
	if(isset($gallery) && count($gallery)>0){
	foreach($gallery as  $single):	?>
		<div class="col-xs-6 col-md-4 galleryitem ">
			<div class="framedecoration">
				<a href="<?php echo base_url();?>gallery/photos/<?php echo $single->id; ?>">
					<img height="200" src="<?php echo base_url();?>/useruploadfiles/galleryimages/<?php echo $single->image; ?>"  title="<?php echo $single->title; ?>" />
				</a>
				<div class="caption">
				<h3 class="glleryTitile text-center overme"><?php echo $single->title;  ?></h3>
				</div>
			</div>
		</div> 
	<?php	endforeach; } ?>
	<nav class="nav-paging ">
		<ul>
		 <?php echo isset($pagination_helper)?$pagination_helper->create_links():""; ?> 
		</ul>
	</nav>		
</section>
            