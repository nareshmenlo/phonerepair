<style type="text/css">
    .brief_desc{
        font-size: 18px;
    }
</style>
<section  id="ccr-left-section" class="col-md-12"> 
        <div class="container  m-b-20"  >
        <div class="col-md-4 sortable-item_style_2 bigstory">
         <div class="headingBtm topics"  style="background: #b36a67;" >
                     
                    <p class="title_color"><a   style="color: #fff !important;" href="<?php echo base_url(); ?>movienews"> <span>MOVIE NEWS</span></a></p>
                </div>
            <section id="sidebar-popular-post">
                <!-- .ccr-gallery-ttile -->

                <ul class="mostpopular_news news_style">
                    <?php if (count($movienews) > 0) { ?> 
                        <?php foreach ($movienews as $movienew): ?>
                            <li>
                                <a  href="<?php echo base_url() . 'movienews/single/' . $movienew->id; ?>"><?php echo $movienew->title; ?></a>
                            </li>
                        <?php endforeach; ?>
                    <?php }else { ?>
                        <li><a>Stories are not available</a></li>
                    <?php } ?>  
                </ul> 
            </section>

        </div>
       <div class="col-md-4 sortable-item_style_2 bigstory">
                <section class="padding0"  id="ccr-slide-main" class="carousel slide" data-ride="carousel">
                    <!-- Carousel items -->
                    <div class="carousel-inner">
                        <?php
                        $banners=getHeaderBanners();
                        $i = 1;
                        if(isset($banners)){
                        foreach ($banners as $banner): if ($i == 1) {
                                ?>
                                <div class="active item">
                                <?php } else { ?>
                                    <div class="item">
                                    <?php } $i++; ?>
                                   
                                    <div class="container slide-element">
                                        <a  href="<?php echo base_url('banner/single/' . $banner->id.'/'.url_title($banner->title)); ?>">
                                        <img src="<?php echo base_url(); ?>useruploadfiles/postimages/<?php echo $banner->image; ?>"
                                             class="img-responsive">
                                        <p><a  href="<?php echo base_url('banner/single/' . $banner->id.'/'.url_title($banner->title)); ?>"><?php echo $banner->title; ?></a></p>
                                        </a>
                                    </div> <!-- /.slide-element -->
                                </div> <!--/.active /.item -->

                                <!-- /.item -->
                            <?php endforeach; } ?>

                        </div> <!-- /.carousel-inner -->

                        <!-- /.carousel-indicators -->

                        <!-- slider nav -->
                        <a class="carousel-control left" href="#ccr-slide-main" data-slide="prev"><i class="fa fa-arrow-left"></i></a>
                        <a class="carousel-control right" href="#ccr-slide-main" data-slide="next"><i class="fa fa-arrow-right"></i></a>
                    </section>

                    <div class="headingBtm topics" style="background:#b36a67;" >
                     
                    <p class="title_color"><a style="color: #fff !important;" href="<?php echo base_url(); ?>moviereviews"> <span>REVIEWS</span></a></p>
                </div> 
            <section id="sidebar-popular-post">
                <!-- .ccr-gallery-ttile -->
                <ul class="mostpopular_news news_style">
                    <?php if (count($reviews) > 0) { ?> 
                        <?php foreach ($reviews as $review): ?>
                            <li>
                                <a  href="<?php echo base_url() . 'moviereviews/single/' . $review->id; ?>"><?php echo $review->title; ?></a>
                            </li>
                        <?php endforeach; ?>
                    <?php }else { ?>
                        <li><a>Reviews are not available</a></li>
                    <?php } ?>  
                </ul>
            </section>
        </div>
        <div class="col-md-4 sortable-item_style_2 bigstory">
        <div class="headingBtm topics" style="background:#b36a67;" >
                     
                    <p class="title_color"><a style="color: #fff !important;" href="<?php echo base_url(); ?>moviereviews"> <span>GOSSIPS</span></a></p>
                </div> 
            <section id="sidebar-popular-post">
                <!-- .ccr-gallery-ttile -->
                <ul class="mostpopular_news news_style">
                    <?php if (count($gossips) > 0) { ?> 
                        <?php foreach ($gossips as $gossip): ?>
                            <li>
                                <a  href="<?php echo base_url() . 'gossips/single/' . $gossip->id; ?>"><?php echo $gossip->title; ?></a>
                            </li>
                        <?php endforeach; ?>
                    <?php }else { ?>
                        <li><a>Gossips are not available</a></li>
                    <?php } ?>  
                </ul>
            </section>
        <div class="headingBtm topics"  style="background: #b36a67;">
                     
                    <p class="title_color" ><a href="<?php echo base_url(); ?>political"  style="color: #fff !important;"> <span>POLITICAL NEWS</span></a></p>
                </div> 
            <section id="sidebar-popular-post">
                <!-- .ccr-gallery-ttile -->
                <ul class="mostpopular_news news_style">
                    <?php if (count($politicalnews) > 0) { ?> 
                        <?php foreach ($politicalnews as $political): ?>
                            <li>
                                <a  href="<?php echo base_url() . 'political/single/' . $political->id; ?>"><?php echo $political->title; ?></a>
                            </li>
                        <?php endforeach; ?>
                    <?php }else { ?>
                        <li><a>political are not available</a></li>
                    <?php } ?>  
                </ul> 
            </section>
        </div>
        
    </div>
    <div class="col-md-12 sortable-item_style_2 video_widg padding0  m-b-20">
        <section id="sidebar-popular-post" class="highlights">
             <!-- .ccr-gallery-ttile -->
             <!-- <div class="col-md-12 padding0">
                <div class="col-md-5  padding0 headingslast">Latest Videos</div>
                <div class="col-md-5  padding0 headingslast">Stills</div>
                <div class="col-md-2  padding0 headingslast">Shortfilms</div>
             </div> -->
             <div class="padding0 " style="clear: both;">
                <?php 
                $videos = latestVideos();
                $shirtfilms = latestShortfilms(); ?>
                <div class="col-md-5 ">
                <div class="col-md-12  padding0 headingslast">VIDEOS</div>

                <?php if(count($videos)>0){
                    foreach($videos as $video){ ?>
                <div class="col-md-6 videosdiv">
                    <a title="" rel="bookmark" href="<?php echo base_url(); ?>videos/index/<?php echo $video->id; ?>" class="thumb">
                        <div class="ytp-thumbnail-overlay1 ytp-cued-thumbnail-overlay" data-layer="4" style="background-image: url('https://i.ytimg.com/vi/<?php echo $video->vedio; ?>/hqdefault.jpg');">
                            <img class="youtubeplaybtn1" style="margin-left:-7%  !important;"  src="<?php echo  asset_url().'/img/youtubeplayas.png'; ?>">
                        </div>
                        </a>
                    <a href="<?php echo base_url(); ?>videos/index/<?php echo $video->id; ?>" class="caption"><?php echo $video->vedio_name; ?></a>
                </div>
                <?php } } ?>
                </div>
                <div class="col-md-5 ">
                                <div class="col-md-12  padding0 headingslast">STILLS</div>

                <?php $images=highlights(); ?>
                    <?php if (count($images)>0){foreach ($images as $key => $image):
                        if($key==2){
                            break;
                        }
                     ?>
                 <div class="col-md-6 videosdiv">
                    <a title="" rel="bookmark" href="<?php echo base_url(); ?>gallery/photos/<?php echo $image->id; ?>" class="thumb">
                        <div class="ytp-thumbnail-overlay1 ytp-cued-thumbnail-overlay" data-layer="4" >
                            <img   src="<?php echo base_url(); ?>useruploadfiles/galleryimages/<?php echo $image->image; ?>" style="height: 150px;">
                        </div>
                        </a>
                    <a href="<?php echo base_url(); ?>gallery/photos/<?php echo $image->id; ?>" class="caption"><?php echo (strlen($image->title)>35)?substr($image->title,0, 35).'..':$image->title;  ?></a>
                </div>
            <?php endforeach;} ?>
            </div><div class="col-md-2 padding0"> 
                            <div class="col-md-12  padding0 headingslast">SHORTFILMS</div>

                <?php if(count($shirtfilms)>0){
                    foreach($shirtfilms as $video){ ?>
                <div class="col-md-12 padding0 videosdiv">
                    <a title="" rel="bookmark" href="<?php echo base_url(); ?>videos/index/<?php echo $video->id; ?>" class="thumb">
                        <div class="ytp-thumbnail-overlay1 ytp-cued-thumbnail-overlay" data-layer="4" style="background-image: url('https://i.ytimg.com/vi/<?php echo $video->vedio; ?>/hqdefault.jpg');">
                            <img class="youtubeplaybtn1"  style="margin-left:-7% !important;"  src="<?php echo  asset_url().'/img/youtubeplayas.png'; ?>">
                        </div>
                        </a>
                    <a href="<?php echo base_url(); ?>videos/index/<?php echo $video->id; ?>" class="caption"><?php echo $video->vedio_name; ?></a>
                </div>
                <?php } } ?>
            </div>

            </div>
        </section>
    </div>
    
    
</section>

