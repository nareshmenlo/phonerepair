<!doctype html>

<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="keywords" content="hyderabad news, telangana news, vizag, online, breaking news in telugu,weather news in telugu,cricket news in telugu" >
        <?php 
        $socialmediaimage=asset_url().'img/fbimage.png'; 
        if(isset($articleimage)){
            if($articleimage!=""){
                $socialmediaimage=base_url().'useruploadfiles/postimages/'.$articleimage;
            }
        } ?>

        

        <meta property="og:image" content="<?php echo $socialmediaimage; ?>"/>
        <meta itemprop="image" content="<?php echo $socialmediaimage; ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">        
        <title><?php echo  $title; ?></title>
        <meta name="author" content="">
        <meta name="description" content="<?php echo isset($description)?$description:''; ?>">
        <link rel="stylesheet" type="text/css" href="<?php echo asset_url(); ?>css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="<?php echo asset_url(); ?>css/bootstrap-theme.min.css">
        <link rel="stylesheet" type="text/css" href="<?php echo asset_url(); ?>css/font-awesome.min.css">
        <!-- <link rel="stylesheet" type="text/css" href="<?php echo asset_url(); ?>css/jquery.social-buttons.css"> -->
        <link rel="stylesheet" type="text/css" href="<?php echo asset_url(); ?>css/style.css">
        <link rel="stylesheet" type="text/css" href="<?php echo asset_url(); ?>css/main.css">
        <!-- <link rel="stylesheet" type="text/css" href="<?php echo asset_url(); ?>css/jquery.share.css"> -->
        <!-- <link href='http://fonts.googleapis.com/css?family=Yesteryear' rel='stylesheet' type='text/css'> -->
        <!-- <link rel="stylesheet" type="text/css" href="http://yui.yahooapis.com/3.18.1/build/cssreset/cssreset-min.css">
        <link rel="stylesheet" type="text/css" href="http://yui.yahooapis.com/3.18.1/build/cssreset-context/cssreset-context-min.css"> -->

        <link rel="stylesheet" type="text/css" href="<?php echo asset_url(); ?>css/owl.carousel.min.css">
        <link rel="stylesheet" type="text/css" href="<?php echo asset_url(); ?>css/owl.theme.default.min.css">


        <!--[if lt IE 9]>
                <script src="js/html5shiv.js"></script>
        <![endif]-->
           
        <script type="text/javascript">
             var current_url="<?php echo current_url(); ?>";
        </script>
   

  <script type="text/javascript">var switchTo5x=true;</script>
<script type="text/javascript" src="http://w.sharethis.com/button/buttons.js"></script>
<script type="text/javascript">stLight.options({publisher: "6899304c-c4f2-4cce-9c22-e359dcdf1d68", doNotHash: false, doNotCopy: false, hashAddressBar: false});</script>
    </head>

    <body >
        
        <header id="ccr-header">
            <section id="ccr-site-title">

                <div class="container main">
                    <div class="col-md-12 col-ms-12 col-sm-12 col-xs-12" style="padding:0px !important;" >
                        <div class="col-md-4 col-xs-12 padding0"> 
                            <a href="<?php echo base_url(); ?>" style="font-size: 60px;font-weight: bold;color: red;"> 
                            <img class="logotag" src="<?php echo asset_url(); ?>img/TOP FILM NEWS (2) copy.png" alt="Site Logo" style="height: 100px;width: 250px;margin-top: 7px;" />
                            <!-- Topfilmnews -->
                            </a>
                            <!-- <p style="    position: absolute;
    margin-top: -47px;
    font-size: 17.5px;margin-left: 72px;
    color: blue;">wwww.topfilmnews.com</p> -->
                        </div>
                        <div class="col-md-8 padding0 headeradd"  style="padding-left: 25px !important;" >
                            <div class="col-md-12 padding0">
                                <img style="height:100px;" src="<?php echo asset_url(); ?>img/add001.jpg" alt="Site Logo" />
                            </div>
                        </div>
                        
                    </div>
                </div>
            </section> <!-- / #ccr-site-title -->

        </header> <!-- /#ccr-header -->

        <section id="ccr-main-section" >
        <?php $this->load->view('partials/nav'); ?>
            <div class="container main">
                
          <div class="col-md-12 padding0" style="position:relative;padding:0px !important;margin-top:-20px;margin-bottom:10px;">
	        <img src="<?php echo asset_url(); ?>img/TANA_1.jpg" />
	    </div>
        <div class="col-md-12 padding0">
        <!-- <section id="sidebar-popular-post" class="highlights" > -->
             <!-- .ccr-gallery-ttile -->
            <!-- <ul class="video_list_spr list-inline "> -->
                <div class="col-md-12 owl-carousel owl-theme m-b-20 padding0">
                <?php $images=highlights(); ?>
                    <?php if (count($images)>0){foreach ($images as $image): ?>
                    <div class="item">
                    <div class="view-img">
                        <a title="<?php echo $image->title; ?>" rel="bookmark" href="<?php echo base_url(); ?>gallery/photos/<?php echo $image->id; ?> " class="video_thumb">
                            <img src="<?php echo base_url(); ?>useruploadfiles/galleryimages/<?php echo $image->image; ?>" onError="this.onerror=null;this.src='<?php echo asset_url(); ?>img/noimage.png';">
                        </a>
                    </div>
                    <div class="view-desc">
                        <h6>
                        <a title="<?php echo $image->title; ?>" href="<?php echo base_url(); ?>gallery/photos/<?php echo $image->id; ?>"><?php echo (strlen($image->title)>35)?substr($image->title,0, 35).'..':$image->title;  ?> </a></h6>
                        <span class="byline"> 
                        </span>
                    </div>
                </div>
            <?php endforeach;} ?>
            </div>
            <?php $lastupdates = getLatestUpdates(); ?>
            <div class="container headerupdate m-b-20 padding0" id="breaking"  >
                <div class="update-ribon col-md-2" style="background:#DA9B59;padding: 5px 13px 11px 30px;">Latest News</div>
                <div class="mar col-md-10 falshnewsscroll padding0" >
                    <marquee style="line-height: 36px;" behavior="scroll" scrollamount="4" direction="left" onmouseover="this.stop();" onmouseout="this.start();">
                        <?php foreach ($lastupdates as $update):
                            $articletitle = url_title($update->title, 'dash', TRUE);
                         ?>
                            <i class="fa fa-arrow-right"></i> <a  class="latestupdate" href="<?php echo base_url('latestupdates/single/' . $update->id.'/'.$articletitle); ?>"><?php echo $update->title; ?></a>
                        <?php endforeach; ?> 
                    </marquee>
                </div>
            </div>
            <!-- </ul> -->
        <!-- </section> -->
        <!-- Set up your HTML -->  </div>
